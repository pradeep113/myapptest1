cftpartid=$1
hostname=$2
platform=$3
log=templates/log.txt
echo "The arguement give are "$1" " $2 "and " $3 "<br><br>">>$log
echo "<font color="green"><h3>test transfer is ongoing</h3></font><br>">>$log
echo "fantastic<br>">>$log
