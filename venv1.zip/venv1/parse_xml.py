import xml.dom.minidom
import sys
firstarg = sys.argv[1]
#secarg = sys.argv[2]
doc = xml.dom.minidom.parse("sample.xml")
dataxml = doc.getElementsByTagName(firstarg)
print dataxml[0].firstChild.nodeValue
for i in range(len(dataxml)):
	print dataxml[i].firstChild.nodeValue
