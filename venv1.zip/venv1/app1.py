from flask import Flask ,render_template ,url_for,request
import os
import subprocess
app = Flask(__name__)
@app.route('/')
def home():
#	return "Hii Again"
	#d = os.popen('test.sh').read()
	return render_template('Index.html')
@app.route('/header')
def header():
	return render_template('header.html')
@app.route('/CFT_midpan')
def CFT_midpan():
        return render_template('CFT_midpan.html')
@app.route('/fotter')
def fotter():
        return render_template('fotter.html')
@app.route('/CFT_mid_leftpan')
def CFT_mid_leftpan():
	return render_template('CFTleftpan.html')
@app.route('/CFT_mid_rightpan')
def CFT_mid_rightpan():
	return render_template('CFTrightpan.html')
@app.route('/CFT_partnerlist')
def CFT_partnerlist():
        return render_template('CFT_patnerlist.html')
@app.route('/CFT_to_CFT_transfer_test')
def CFT_to_CFT_transfer_test():
        return render_template('CFT_to_CFT_transfer_test.html')
@app.route('/CFT_to_CFT_dataflow_creation')
def CFT_to_CFT_dataflow_creation():
        return render_template('CFT_to_CFT_dataflow_creation.html')
@app.route('/CFT_transfer_Analysis')
def CFT_transfer_Analysis():
        return render_template('CFT_transfer_Analysis.html')
@app.route('/CFT_to_CFT_parameter_validation')
def CFT_to_CFT_parameter_validation():
        return render_template('CFT_to_CFT_parameter_validation.html')
@app.route('/CFT_partnerlist_content')
def CFT_partnerlist_content():
	return render_template('CFT_partnerlist.txt')

#Shell scripts execute 
@app.route('/exec_CFT_to_CFT_transfer_test', methods=['GET','POST'])
def exec_CFT_to_CFT_transfer_test():
	if request.method == 'POST':
		cftpartid = request.form['cftpartid']
		hostname = request.form['hostname']
		platform = request.form['platform']
		cmd = ["sh","CFT_to_CFT_transfer_test.sh"]
		cmd.append(cftpartid)
 		cmd.append(hostname)
		cmd.append(platform)	
		p = subprocess.Popen(cmd, stdout = subprocess.PIPE, stderr = subprocess.PIPE, stdin = subprocess.PIPE)
		out,err = p.communicate()
		return render_template('CFT_to_CFT_transfer_test.html') 
@app.route('/log_CFT_to_CFT_transfer_test')
def log_CFT_to_CFT_transfer_test():
        return render_template('log.txt')


app.run(host='0.0.0.0' ,port = 80,debug = True)
