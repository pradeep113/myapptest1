echo "hello Pradeep">>log.dat
mkdir pdd
echo "hell"
